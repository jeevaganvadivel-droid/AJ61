<?php
$serviceKey='cable-laying-tray-fixing';
require __DIR__.'/service-page.php';
