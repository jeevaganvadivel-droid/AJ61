<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
const SITE_NAME='AJ SIXTY ONE PTE LTD';
const LIVE_URL='https://ajsixtyone.sg';
const CONTACT_EMAIL='info.ajsixtyone@gmail.com';
const CONTACT_PHONE='+65 6659 1683';
const CONTACT_PHONE_RAW='6566591683';
const WHATSAPP_NUMBER='+65 8363 4675';
const WHATSAPP_RAW='6583634675';
const COMPANY_ADDRESS='7030 Ang Mo Kio Avenue 5, #01-07 NorthStar @ AMK, Singapore 569880';
const POSTAL_CODE='569880';

function site_path(): string {
    $host=$_SERVER['HTTP_HOST']??'';
    $script=str_replace('\\','/',$_SERVER['SCRIPT_NAME']??'');
    if(str_contains($host,'localhost')||str_starts_with($host,'127.0.0.1')){
        $p=array_values(array_filter(explode('/',trim($script,'/'))));
        return count($p)>1?'/'.$p[0]:'';
    }
    return '';
}
function site_url(string $path=''): string {
    $b=site_path();
    if($path===''||$path==='/') return $b.'/';
    if($path[0]==='#'||$path[0]==='?') return $b.'/'.$path;
    return $b.'/'.ltrim($path,'/');
}
function asset(string $path): string { return site_path().'/'.ltrim($path,'/'); }
function e(string $v): string { return htmlspecialchars($v,ENT_QUOTES,'UTF-8'); }
function canonical(string $path=''): string { return LIVE_URL.'/'.ltrim($path,'/'); }
function whatsapp_url(string $m=''): string { $u='https://wa.me/'.WHATSAPP_RAW; return $m?$u.'?text='.rawurlencode($m):$u; }
function json_ld(array $data): string { return '<script type="application/ld+json">'.json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE).'</script>'; }

if(empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32));
function service_options(): array { return ['Electrical Wire Laying','Conduit Pipe Fittings','Electrical Trunking & Fittings','Cable Laying & Tray Fixing','Electrical DB / DP Configuration & Panel Works','Street Light Fix & Maintenance','Plumbing Services','Structural Works','Painting Services','Fire Fighting Works','Jetting Works','Other / Site Requirement']; }
function status_message(): ?array { return match($_GET['status']??''){ 'success'=>['success','Thank you. Your enquiry has been received.'], 'invalid'=>['error','Please check the form and try again.'], 'rate'=>['error','Please wait a moment before sending another enquiry.'], 'mail-error'=>['error','Email delivery failed. Please WhatsApp or call us.'], default=>null}; }
function image_dimensions(string $path): array {
    static $m=[
        'assets/img/web/hero-construction.webp'=>[1800,1200],
        'assets/img/web/hero-electrical.webp'=>[1800,2698],
        'assets/img/web/hero-painting.webp'=>[1800,2698],
        'assets/img/web/hero-plumbing.webp'=>[1800,3197],
        'assets/img/web/hero-streetlight.webp'=>[1800,1218],
        'assets/img/web/hero-structure.webp'=>[1800,1200],
        'assets/img/aj61-logo.png'=>[1024,1024],
        'assets/img/aj61-logo-tile.png'=>[512,512],
    ];
    if(preg_match('~assets/img/gallery/g\\d{2}\\.webp$~',$path)) return [760,878];
    return $m[$path]??[1200,800];
}
function responsive_sources(string $path): ?array {
    if(!str_starts_with($path,'assets/img/web/') || !str_ends_with($path,'.webp')) return null;
    $name=basename($path,'.webp');
    return [
      'avif'=>asset('assets/img/web/responsive/'.$name.'-960.avif').' 960w, '.asset('assets/img/web/responsive/'.$name.'-1600.avif').' 1600w',
      'webp'=>asset('assets/img/web/responsive/'.$name.'-960.webp').' 960w, '.asset('assets/img/web/responsive/'.$name.'-1600.webp').' 1600w',
    ];
}
function responsive_img(string $path,string $alt='',string $class='',string $loading='lazy',string $sizes='100vw',string $extra=''): string {
    [$w,$h]=image_dimensions($path); $src=responsive_sources($path);
    $attrs=' src="'.e(asset($path)).'" alt="'.e($alt).'" width="'.$w.'" height="'.$h.'" loading="'.e($loading).'" decoding="async"';
    if($class!=='') $attrs.=' class="'.e($class).'"';
    if($loading==='eager') $attrs.=' fetchpriority="high"';
    if($extra!=='') $attrs.=' '.$extra;
    if(!$src) return '<img'.$attrs.'>';
    return '<picture><source type="image/avif" srcset="'.e($src['avif']).'" sizes="'.e($sizes).'"><source type="image/webp" srcset="'.e($src['webp']).'" sizes="'.e($sizes).'">'.'<img'.$attrs.' sizes="'.e($sizes).'"></picture>';
}
function wa_icon(string $cls='wa-svg'): string { return '<svg class="'.$cls.'" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>'; }
