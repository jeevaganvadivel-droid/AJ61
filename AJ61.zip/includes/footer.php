</main>
<footer class="footer" id="top">
  <div class="footer__hex" aria-hidden="true"></div>
  <div class="container">
    <a class="footer__cta" href="<?=e(site_url('contact.php'))?>" data-cursor="view" data-label="Talk">
      <small>Have a project in mind?</small>
      <span class="footer__big"><span class="fl"><span>Let&rsquo;s build</span></span><span class="fl"><span>what&rsquo;s next.</span></span></span>
      <i class="footer__arrow" aria-hidden="true"></i>
    </a>
    <div class="footer__grid">
      <div class="f-brand">
        <span class="logo-tile logo-tile--lg"><img src="<?=e(asset('assets/img/aj61-logo-tile.png'))?>" alt="AJ SIXTY ONE logo"></span>
        <p>Electrical, plumbing, structural and finishing works across Singapore, coordinated by one team.</p>
        <a class="wa-pill" href="<?=e(whatsapp_url('Hi AJ SIXTY ONE, I would like to discuss a project.'))?>" target="_blank" rel="noopener"><?=wa_icon()?><span><?=e(WHATSAPP_NUMBER)?></span></a>
      </div>
      <div class="f-col f-col--wide"><small>Services</small><ul class="f-services"><?php foreach($services as $slug=>$sv):?><li><a href="<?=e(site_url($slug.'.php'))?>"><?=e($sv['title'])?></a></li><?php endforeach;?></ul></div>
      <div class="f-col"><small>Explore</small><ul><li><a href="<?=e(site_url('#services'))?>">Services</a></li><li><a href="<?=e(site_url('#industries'))?>">Industries</a></li><li><a href="<?=e(site_url('#capabilities'))?>">Capabilities</a></li><li><a href="<?=e(site_url('#gallery'))?>">Gallery</a></li><li><a href="<?=e(site_url('#process'))?>">Process</a></li><li><a href="<?=e(site_url('contact.php'))?>">Contact</a></li><li><a href="<?=e(site_url('privacy.php'))?>">Privacy</a></li></ul></div>
      <div class="f-col"><small>Contact</small><ul><li><a href="tel:<?=CONTACT_PHONE_RAW?>"><?=e(CONTACT_PHONE)?></a></li><li><a href="mailto:<?=e(CONTACT_EMAIL)?>"><?=e(CONTACT_EMAIL)?></a></li><li class="f-addr"><?=e(COMPANY_ADDRESS)?></li></ul></div>
    </div>
    <div class="footer-word" aria-hidden="true">AJ SIXTY ONE</div>
    <div class="footer__bottom"><span>&copy; <?=date('Y')?> AJ SIXTY ONE PTE LTD. All rights reserved. · <a href="<?=e(site_url('privacy.php'))?>">Privacy Policy</a></span><button class="totop" data-top aria-label="Back to top"><svg viewBox="0 0 24 24"><path d="M12 19V5M5.5 11.5 12 5l6.5 6.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>
  </div>
</footer>
<a class="wa-float" href="<?=e(whatsapp_url('Hi AJ SIXTY ONE, I need a quotation.'))?>" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><?=wa_icon()?></a>
<div class="lb" data-lightbox aria-hidden="true" role="dialog" aria-label="Gallery"><button class="lb__close" aria-label="Close"></button><button class="lb__nav lb__prev" aria-label="Previous"></button><button class="lb__nav lb__next" aria-label="Next"></button><figure class="lb__fig"><div class="lb__frame"><img alt=""></div><figcaption></figcaption></figure></div>
<script src="<?=e(asset('assets/js/vendor/gsap.min.js'))?>" defer></script><script src="<?=e(asset('assets/js/vendor/ScrollTrigger.min.js'))?>" defer></script><script src="<?=e(asset('assets/js/vendor/lenis.min.js'))?>" defer></script><script src="<?=e(asset('assets/js/hero-gl.js'))?>?v=16" defer></script><script src="<?=e(asset('assets/js/main.js'))?>?v=16" defer></script></body></html>
