<?php
$serviceKey='jetting-works';
require __DIR__.'/service-page.php';
