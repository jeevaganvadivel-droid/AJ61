<?php
if(!defined('SITE_NAME')) require __DIR__.'/includes/bootstrap.php';
http_response_code(404); $pageTitle='Page Not Found | '.SITE_NAME; $pageDescription='The requested page could not be found.'; $canonical=canonical('404.php');
require __DIR__.'/includes/header.php'; ?>
<section class="notfound"><div class="container"><span class="eyebrow">404</span><h1>That page is not here.</h1><p>The link may have changed. You can return to the homepage, explore services or send us your project requirement.</p><div class="hero__actions"><a class="btn" href="<?=e(site_url())?>"><span>Back to home</span><i class="ic"></i></a><a class="btn btn--light" href="<?=e(site_url('#services'))?>"><span>View services</span><i class="ic"></i></a></div></div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
