<?php
declare(strict_types=1); require __DIR__.'/includes/bootstrap.php';
function back(string $status): never { header('Location: '.site_url('?status='.$status.'#quote')); exit; }
if($_SERVER['REQUEST_METHOD']!=='POST') { header('Location: '.site_url()); exit; }
if(!hash_equals($_SESSION['csrf_token']??'',(string)($_POST['csrf_token']??''))) back('invalid');
if(!empty($_POST['website']??'')) back('success');
$now=time(); if(isset($_SESSION['last_enquiry']) && $now-(int)$_SESSION['last_enquiry']<20) back('rate');
$name=trim((string)($_POST['name']??'')); $company=trim((string)($_POST['company']??'')); $phone=trim((string)($_POST['phone']??''));
$emailRaw=trim((string)($_POST['email']??'')); $email=filter_var($emailRaw,FILTER_VALIDATE_EMAIL); $service=trim((string)($_POST['service']??'')); $message=trim((string)($_POST['message']??''));
if(strlen($name)>100||strlen($company)>120||strlen($phone)>40||strlen($emailRaw)>160||strlen($message)>2000) back('invalid');
if(preg_match('/[\r\n]/',$emailRaw.$name.$service)) back('invalid');
if(!$name||!$phone||!$email||!in_array($service,service_options(),true)||!$message||($_POST['consent']??'')!=='1') back('invalid');
$subject='AJ61 Website Enquiry: '.$service;
$body="AJ SIXTY ONE WEBSITE ENQUIRY\n\nName: $name\nCompany: $company\nPhone: $phone\nEmail: $email\nService: $service\n\nProject details:\n$message\n\nSubmitted: ".date('Y-m-d H:i:s T');
$headers='From: AJ SIXTY ONE Website <website@ajsixtyone.sg>'."\r\n".'Reply-To: '.$email."\r\n".'MIME-Version: 1.0'."\r\n".'Content-Type: text/plain; charset=UTF-8';
$ok=@mail(CONTACT_EMAIL,$subject,$body,$headers);
$_SESSION['last_enquiry']=$now; $_SESSION['csrf_token']=bin2hex(random_bytes(32)); back($ok?'success':'mail-error');
