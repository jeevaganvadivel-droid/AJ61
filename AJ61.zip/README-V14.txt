AJ61 V14 — Brand Octagon Header + Service Showcase

Changes:
- Desktop menu buttons now use AJ61 purple/magenta branding rather than grey.
- WhatsApp remains green for correct recognition.
- Horizontal scrolling service cards are true elongated 8-sided octagons.
- CTA card and small action buttons use matching octagonal geometry.
- Mobile service list receives a lighter octagonal treatment.
- Existing fonts, SEO, pages and responsive behaviour are preserved.
