<?php
$serviceKey='conduit-pipe-fittings';
require __DIR__.'/service-page.php';
