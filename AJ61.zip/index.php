<?php
require __DIR__.'/includes/bootstrap.php';
require __DIR__.'/includes/service-data.php';
$pageTitle='AJ SIXTY ONE PTE LTD | Electrical, Plumbing & Building Services Singapore';
$pageDescription='AJ SIXTY ONE provides electrical wire laying, conduit, trunking, cable tray, DB/DP, plumbing, structural and painting works in Singapore with a premium digital experience.';
$pageKeywords='electrical contractor Singapore, cable laying Singapore, conduit pipe fittings, trunking, cable tray, plumbing, structural works, painting services';
$canonical=canonical();
$preloadImage='assets/img/web/ajsixtone all services.AVIF';
require __DIR__.'/includes/header.php';
?>

<section class="hero" data-hero>
  <div class="hero__media"><?=responsive_img('assets/img/web/ajsixtone all services.WEBP','Construction and multi-trade project works','','eager','100vw')?></div>
  <svg class="hero__oct" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" aria-hidden="true"><defs><linearGradient id="octGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#d047bb"/><stop offset="1" stop-color="#a0238e" stop-opacity=".15"/></linearGradient></defs><path d="M30 2H70L98 30V70L70 98H30L2 70V30Z"/></svg>
  <div class="badge" data-intro aria-hidden="true"><svg viewBox="0 0 120 120"><defs><path id="bc" d="M60,60 m-47,0 a47,47 0 1,1 94,0 a47,47 0 1,1 -94,0"/></defs><text><textPath href="#bc" textLength="292">Electrical • Plumbing • Structural • Painting • Springlar • </textPath></text></svg><span class="logo-tile logo-tile--badge"><img src="<?= e(asset('assets/img/aj61-logo-tile.png')) ?>" alt=""></span></div>
  <div class="container hero__inner">
    <h1 aria-label="Power it. Pipe it. Build it."><span class="line"><span>Power it.</span></span><span class="line"><span>Pipe it.</span></span><span class="line"><span>Build it.</span></span></h1>
    <div class="hero__row">
      <p data-intro>Electrical, plumbing, structural and finishing works across Singapore, coordinated by one team with one point of contact.</p>
      <div class="hero__actions" data-intro>
        <a class="btn" data-magnetic href="#quote"><span>Request a quotation</span><i class="ic"></i></a>
        <a class="btn-wa" data-magnetic target="_blank" rel="noopener" aria-label="Chat on WhatsApp" href="<?= e(whatsapp_url('Hi AJ SIXTY ONE, I would like to discuss a project.')) ?>"><?= wa_icon() ?></a>
      </div>
    </div>
  </div>
  <div class="hero__foot" data-intro><div class="container"><div class="hero__tags"><span>Electrical</span><span>Containment</span><span>Plumbing</span><span>Structural</span><span>Painting</span><span>Fire fighting</span></div><div class="scroll-cue"><span>Scroll</span><i></i></div></div></div>
</section>

<div class="marquee" aria-hidden="true"><div class="marquee__track"><?php for($k=0;$k<2;$k++): foreach($services as $s0):?><span><?= e($s0['title']) ?></span><?php endforeach; endfor;?></div></div>

<section class="statement">
  <div class="container">

    <p data-scrub-text>
      One site. One team. Every solution — planned, coordinated and delivered together.
    </p>

    <div class="statement__meta">

      <div class="rv">
        <b><?= count($services) ?></b>
        <span>service scopes covering electrical, plumbing, structural, painting and site works</span>
      </div>

      <div class="rv">
        <b>1</b>
        <span>coordinated team and one point of contact throughout the project</span>
      </div>

      <div class="rv">
        <b>FAST</b>
        <span>send site photos, drawings and requirements directly through WhatsApp</span>
      </div>

    </div>

  </div>
</section>
<section class="portal" data-portal>
  <div class="portal__bg" aria-hidden="true"><span class="portal__word">ONE TEAM.<br>EVERY SOLUTION.</span></div>
  <div class="portal__mask"><img src="<?= e(asset('assets/img/web/hero-structure.webp')) ?>" alt="Steel structure under construction"></div>
  <div class="container portal__copy">
    <h2>ONE TEAM.<br>EVERY SOLUTION.</h2>
    <p>From the first cable route to the final coat of paint, the same team stays accountable.</p>
    <a class="btn btn--light" data-magnetic href="#services"><span>See what we cover</span><i class="ic"></i></a>
  </div>
</section>

<section class="services" id="services"><div class="container">
  <div class="sec-head"><h2 data-split>Everything the site needs, from one team.</h2><p class="rv">Choose a single scope or combine several under one programme. Each page shows what is included and how to enquire.</p></div>
  <div class="svc-list">
    <?php foreach($services as $slug=>$s): ?>
    <a class="svc" href="<?= e(site_url($slug.'.php')) ?>">
      <img class="svc__thumb" src="<?= e(asset($s['image'])) ?>" alt="" loading="lazy">
      <span class="svc__name"><?= e($s['title']) ?></span>
      <span class="svc__kick"><?= e(ucfirst(strtolower($s['kicker']))) ?></span>
      <i class="go" aria-hidden="true"></i>
    </a>
    <?php endforeach; ?>
  </div>
</div></section>

<section class="showcase" data-showcase aria-label="Services">
  <div class="showcase__pin">
    <div class="showcase__track" data-showcase-track>
      <?php $pos=['50% 35%','25% 55%','75% 40%','50% 65%','35% 30%','65% 60%']; $n=0; foreach($services as $slug=>$s): ?>
      <a class="card" href="<?= e(site_url($slug.'.php')) ?>" data-cursor="view">
        <div class="card__img"><img src="<?= e(asset($s['image'])) ?>" alt="<?= e($s['title']) ?>" style="object-position:<?= $pos[$n%6] ?>" loading="lazy"></div>
        <span class="card__kick"><?= e(ucfirst(strtolower($s['kicker']))) ?></span>
        <div class="card__body"><h3><?= e($s['title']) ?></h3><p><?= e($s['short']) ?></p></div>
        <i class="go" aria-hidden="true"></i>
      </a>
      <?php $n++; endforeach; ?>
      <a class="card card--cta" href="#quote"><div class="card__body"><h3>Have a site requirement?</h3><p>Tell us the scope and location. We will come back with a plan.</p><span class="btn btn--light"><span>Start a project</span><i class="ic"></i></span></div></a>
    </div>
    <div class="showcase__bar" aria-hidden="true"><i></i></div>
  </div>
</section>

<section class="story" id="capabilities" data-story>
  <div class="story__layer"><img src="<?= e(asset('assets/img/web/hero-electrical.webp')) ?>" alt=""></div>
  <div class="story__layer"><img src="<?= e(asset('assets/img/web/hero-structure.webp')) ?>" alt=""></div>
  <div class="story__layer"><img src="<?= e(asset('assets/img/web/hero-painting.webp')) ?>" alt=""></div>
  <div class="container story__grid">
    <h2>From first route to final coat.</h2>
    <div class="story__steps">
      <article class="story__step"><small>Route</small><h3>Plan the path.</h3><p>Wire, conduit and cable tray routes are set out around access, equipment and the other trades on site.</p></article>
      <article class="story__step"><small>Build</small><h3>Install in sequence.</h3><p>Conduit, trunking, tray and support works go in with the right order of trades, so work is not opened up twice.</p></article>
      <article class="story__step"><small>Finish</small><h3>Hand over a complete site.</h3><p>Plumbing, structural support and painting close the loop from infrastructure to handover.</p></article>
    </div>
  </div>
  <div class="story__rail" aria-hidden="true"><i><b></b></i><i><b></b></i><i><b></b></i></div>
</section>


<section class="industries" id="industries"><div class="container">
  <div class="sec-head"><h2 data-split>Built for active sites.</h2><p class="rv">AJ SIXTY ONE supports project enquiries across commercial, industrial and building environments. Final scope is reviewed against the actual site requirement.</p></div>
  <div class="industry-grid">
    <article class="industry rv"><span>01</span><h3>Commercial</h3><p>Offices, retail units, common areas and commercial fit-out requirements.</p></article>
    <article class="industry rv"><span>02</span><h3>Industrial</h3><p>Industrial spaces, workshops, service areas and infrastructure upgrades.</p></article>
    <article class="industry rv"><span>03</span><h3>Facilities</h3><p>Maintenance, alteration and improvement works for managed properties.</p></article>
    <article class="industry rv"><span>04</span><h3>Renovation</h3><p>Multi-trade scopes that need electrical, plumbing, structural and finishing coordination.</p></article>
    <article class="industry rv"><span>05</span><h3>Warehouses</h3><p>Cable routes, containment, lighting, support works and related project requirements.</p></article>
    <article class="industry rv"><span>06</span><h3>Building Management</h3><p>Site-based repair, upgrade and coordination requirements with clear contact flow.</p></article>
  </div>
</div></section>

<section class="project-scopes"><div class="container">
  <div class="sec-head"><h2 data-split>Project scopes we can coordinate.</h2><p class="rv">These are example scope combinations, not claims about completed projects. Replace them later with your real project photos and details.</p></div>
  <div class="project-scopes__grid">
    <article class="project-scope rv"><div class="project-scope__media"><?=responsive_img('assets/img/web/hero-electrical.webp','Electrical and cable containment scope','','lazy','(max-width: 900px) 100vw, 50vw')?></div><div><small>Example scope 01</small><h3>Electrical + containment</h3><p>Wire laying, conduit, trunking, cable tray and related route coordination in one work package.</p><a href="<?=e(site_url('electrical-wire-laying.php'))?>">Explore electrical works ↗</a></div></article>
    <article class="project-scope rv"><div class="project-scope__media"><?=responsive_img('assets/img/web/hero-plumbing.webp','Plumbing and building support scope','','lazy','(max-width: 900px) 100vw, 50vw')?></div><div><small>Example scope 02</small><h3>Plumbing + supporting works</h3><p>Pipe routing and alteration requirements coordinated with surrounding building services and access.</p><a href="<?=e(site_url('plumbing-services.php'))?>">Explore plumbing works ↗</a></div></article>
    <article class="project-scope rv"><div class="project-scope__media"><?=responsive_img('assets/img/web/hero-painting.webp','Painting and finishing scope','','lazy','(max-width: 900px) 100vw, 50vw')?></div><div><small>Example scope 03</small><h3>Structural + finishing</h3><p>Supporting site works followed by preparation, painting and finishing where required by the project.</p><a href="<?=e(site_url('painting-services.php'))?>">Explore finishing works ↗</a></div></article>
  </div>
</div></section>

<section class="why-aj"><div class="container why-aj__grid">
  <div><small class="eyebrow">WHY AJ SIXTY ONE</small><h2 data-split>One contact. Fewer handovers.</h2><p class="rv">The value is coordination: related scopes can be discussed together instead of forcing the client to repeat the same site information to multiple parties.</p></div>
  <div class="why-aj__list">
    <article class="rv"><b>01</b><h3>Multi-trade coordination</h3><p>Electrical, plumbing, structural and finishing requirements can be reviewed as one project conversation.</p></article>
    <article class="rv"><b>02</b><h3>Direct communication</h3><p>Send site photos, drawings, location and timing directly through WhatsApp or the website form.</p></article>
    <article class="rv"><b>03</b><h3>Clear scope first</h3><p>Work sequence, access and required scope are reviewed before mobilisation.</p></article>
  </div>
</div></section>

<section class="home-faq"><div class="container faq-grid"><div><small class="eyebrow">FAQ</small><h2 data-split>Before you send the enquiry.</h2></div><div class="faq-list">
  <details class="rv"><summary>Can I combine several services in one enquiry?</summary><p>Yes. List all required scopes in the project details and include photos or drawings where available.</p></details>
  <details class="rv"><summary>Can I send site drawings through WhatsApp?</summary><p>Yes. WhatsApp is available for project photos, drawings, location information and preferred timing.</p></details>
  <details class="rv"><summary>Do you accept commercial and industrial project enquiries?</summary><p>Yes. AJ SIXTY ONE accepts enquiries for commercial, industrial, renovation and building environments, subject to the actual site scope.</p></details>
  <details class="rv"><summary>What information helps you review a quotation request?</summary><p>The service required, site location, photos or drawings, approximate scope and preferred timing are the most useful starting details.</p></details>
</div></div></section>

<section class="gallery" id="gallery" data-gallery>
  <div class="container gallery__head"><h2 data-split>Life on site.</h2><p class="rv">The people, tools and work behind every handover. Tap any tile to open it full screen.</p></div>
  <div class="hexgrid" data-hexgrid>
    <div class="hexrow"><button class="hx" data-src="<?= e(asset('assets/img/gallery/g01.webp')) ?>" data-cap="Cable routing in progress" data-cursor="view" data-label="Open" aria-label="Open photo: Cable routing in progress"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g01.webp')) ?>" alt="Cable routing in progress" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g02.webp')) ?>" data-cap="Steel frame installation" data-cursor="view" data-label="Open" aria-label="Open photo: Steel frame installation"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g02.webp')) ?>" alt="Steel frame installation" loading="lazy"></span></button><div class="hx hx--brand" aria-hidden="true"><span class="hx__in"><b>Real sites.<br>Real teams.</b></span></div><button class="hx" data-src="<?= e(asset('assets/img/gallery/g03.webp')) ?>" data-cap="Distribution board works" data-cursor="view" data-label="Open" aria-label="Open photo: Distribution board works"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g03.webp')) ?>" alt="Distribution board works" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g04.webp')) ?>" data-cap="Painting and finishing" data-cursor="view" data-label="Open" aria-label="Open photo: Painting and finishing"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g04.webp')) ?>" alt="Painting and finishing" loading="lazy"></span></button></div>
    <div class="hexrow"><button class="hx" data-src="<?= e(asset('assets/img/gallery/g05.webp')) ?>" data-cap="Plumbing installation" data-cursor="view" data-label="Open" aria-label="Open photo: Plumbing installation"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g05.webp')) ?>" alt="Plumbing installation" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g06.webp')) ?>" data-cap="Street light maintenance" data-cursor="view" data-label="Open" aria-label="Open photo: Street light maintenance"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g06.webp')) ?>" alt="Street light maintenance" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g07.webp')) ?>" data-cap="Crane lift on site" data-cursor="view" data-label="Open" aria-label="Open photo: Crane lift on site"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g07.webp')) ?>" alt="Crane lift on site" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g08.webp')) ?>" data-cap="Site team at work" data-cursor="view" data-label="Open" aria-label="Open photo: Site team at work"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g08.webp')) ?>" alt="Site team at work" loading="lazy"></span></button></div>
    <div class="hexrow"><button class="hx" data-src="<?= e(asset('assets/img/gallery/g09.webp')) ?>" data-cap="Panel wiring detail" data-cursor="view" data-label="Open" aria-label="Open photo: Panel wiring detail"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g09.webp')) ?>" alt="Panel wiring detail" loading="lazy"></span></button><div class="hx hx--logo" aria-hidden="true"><span class="hx__in"><img src="<?= e(asset('assets/img/aj61-logo-tile.png')) ?>" alt=""></span></div><button class="hx" data-src="<?= e(asset('assets/img/gallery/g10.webp')) ?>" data-cap="Surface preparation" data-cursor="view" data-label="Open" aria-label="Open photo: Surface preparation"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g10.webp')) ?>" alt="Surface preparation" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g11.webp')) ?>" data-cap="Pipework fit-out" data-cursor="view" data-label="Open" aria-label="Open photo: Pipework fit-out"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g11.webp')) ?>" alt="Pipework fit-out" loading="lazy"></span></button><button class="hx" data-src="<?= e(asset('assets/img/gallery/g12.webp')) ?>" data-cap="Outdoor lighting repair" data-cursor="view" data-label="Open" aria-label="Open photo: Outdoor lighting repair"><span class="hx__in"><img src="<?= e(asset('assets/img/gallery/g12.webp')) ?>" alt="Outdoor lighting repair" loading="lazy"></span></button></div>
  </div>
</section>

<section class="process" id="process"><div class="container">
  <div class="sec-head"><h2 data-split>Four steps from enquiry to handover.</h2><p class="rv">A short, clear path so you always know what happens next.</p></div>
  <div class="process__grid">
    <div class="process__line" aria-hidden="true"><i></i></div>
    <article class="step rv"><span>01</span><h3>Share the scope</h3><p>Send photos, location, drawings and the timing you need.</p></article>
    <article class="step rv"><span>02</span><h3>Review the site</h3><p>We check access, sequence and where trades need coordinating.</p></article>
    <article class="step rv"><span>03</span><h3>Quote and plan</h3><p>You get a confirmed scope, price and programme.</p></article>
    <article class="step rv"><span>04</span><h3>Install and hand over</h3><p>We complete the agreed work and hand over clearly.</p></article>
  </div>
</div></section>

<section class="lead" id="quote"><div class="container lead__grid">
  <div class="lead__copy">
    <h2 data-split>Tell us what the site needs.</h2>
    <p class="rv">For the fastest reply, send the service, location, photos and preferred timing on WhatsApp. Prefer email? Use the form.</p>
    <div class="lead__direct rv">
      <a href="<?= e(whatsapp_url('Hi AJ SIXTY ONE, I would like to request a quotation.')) ?>" target="_blank" rel="noopener"><span class="ld-ic ld-ic--wa"><?= wa_icon() ?></span><span><small>WhatsApp</small><b><?= e(WHATSAPP_NUMBER) ?></b></span></a>
      <a href="tel:<?= CONTACT_PHONE_RAW ?>"><span class="ld-ic"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1z"/></svg></span><span><small>Call</small><b><?= e(CONTACT_PHONE) ?></b></span></a>
    </div>
  </div>
  <div class="lead__form rv"><?php require __DIR__.'/includes/lead-form.php'; ?></div>
</div></section>

<?php echo json_ld(['@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>[
 ['@type'=>'Question','name'=>'Can I combine several services in one enquiry?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Yes. List all required scopes in the project details and include photos or drawings where available.']],
 ['@type'=>'Question','name'=>'Can I send site drawings through WhatsApp?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Yes. WhatsApp is available for project photos, drawings, location information and preferred timing.']],
 ['@type'=>'Question','name'=>'Do you accept commercial and industrial project enquiries?','acceptedAnswer'=>['@type'=>'Answer','text'=>'Yes. AJ SIXTY ONE accepts enquiries for commercial, industrial, renovation and building environments, subject to the actual site scope.']],
 ['@type'=>'Question','name'=>'What information helps you review a quotation request?','acceptedAnswer'=>['@type'=>'Answer','text'=>'The service required, site location, photos or drawings, approximate scope and preferred timing are useful starting details.']]
]]); ?>

<?php require __DIR__.'/includes/footer.php'; ?>
