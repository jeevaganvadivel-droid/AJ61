AJ61 V16 — Perfect Regular Octagon Portal

Changes:
- Portal image starts as a true regular 8-sided octagon.
- Width and height remain identical during the entire animation.
- Uses the AJ61 regular octagon geometry: 29.289% / 70.711%.
- Shape no longer stretches into an elongated octagon.
- The octagon grows beyond the viewport to reveal a full-screen image while preserving equal sides.
- Desktop start size: 28vmin; mobile: 34vmin.
- Existing V15 header, service showcase, SEO and site content retained.

Clear browser cache with Ctrl+F5 after replacing files.
