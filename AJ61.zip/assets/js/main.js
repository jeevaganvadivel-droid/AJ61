/* AJ SIXTY ONE — V8 motion engine
   Lenis smooth scroll + GSAP ScrollTrigger + WebGL hero (hero-gl.js) */
(() => {
  const d = document, root = d.documentElement;
  const $ = (s, c = d) => c.querySelector(s);
  const $$ = (s, c = d) => [...c.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hasLib = window.gsap && window.ScrollTrigger && window.Lenis;
  const header = $('[data-header]');
  let lenis = null;

  /* ---------- Menu ---------- */
  const menuBtn = $('[data-menu-btn]');
  const menuEl = $('[data-menu]');
  const setMenu = open => {
    if (open && menuBtn && menuEl) {
      const r = menuBtn.getBoundingClientRect();
      menuEl.style.setProperty('--mx', (r.left + r.width / 2) + 'px');
      menuEl.style.setProperty('--my', (r.top + r.height / 2) + 'px');
    }
    root.classList.toggle('menu-open', open);
    menuBtn && menuBtn.setAttribute('aria-expanded', open);
    if (lenis) open ? lenis.stop() : lenis.start(); else d.body.style.overflow = open ? 'hidden' : '';
  };
  menuBtn && menuBtn.addEventListener('click', () => setMenu(!root.classList.contains('menu-open')));
  $$('.menu a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  addEventListener('keydown', e => e.key === 'Escape' && setMenu(false));

  /* ---------- Header ---------- */
  let lastY = 0;
  const onScroll = () => {
    const y = scrollY;
    header.classList.toggle('is-scrolled', y > 40);
    root.classList.toggle('past-hero', y > innerHeight * 0.7);
    header.classList.toggle('is-hidden', y > 600 && y > lastY + 4 && !root.classList.contains('menu-open'));
    if (y < lastY - 4) header.classList.remove('is-hidden');
    lastY = y;
  };
  addEventListener('scroll', onScroll, { passive: true }); onScroll();


  /* ---------- Gallery lightbox (CSS-driven, works without GSAP) ---------- */
  const lbEl = $('[data-lightbox]');
  if (lbEl) {
    const frame = $('.lb__frame', lbEl), im = $('img', frame), cap = $('figcaption', lbEl);
    let list = [], cur = 0;
    const show = i => { cur = (i + list.length) % list.length; im.src = list[cur].dataset.src; im.alt = cap.textContent = list[cur].dataset.cap || ''; };
    const open = i => {
      list = $$('.hx[data-src]').filter(t => t.offsetParent !== null);
      if (!list.length) return;
      show(i); lbEl.classList.add('is-open'); lbEl.setAttribute('aria-hidden', 'false'); lenis && lenis.stop();
      if (!lenis) d.body.style.overflow = 'hidden';
    };
    const close = () => { lbEl.classList.remove('is-open'); lbEl.setAttribute('aria-hidden', 'true'); lenis && lenis.start(); if (!lenis) d.body.style.overflow = ''; };
    const go = dir => { frame.classList.add('swap'); setTimeout(() => { show(cur + dir); frame.classList.remove('swap'); }, 260); };
    $$('.hx[data-src]').forEach(t => t.addEventListener('click', () => open($$('.hx[data-src]').filter(x => x.offsetParent !== null).indexOf(t))));
    $('.lb__close', lbEl).addEventListener('click', close);
    $('.lb__prev', lbEl).addEventListener('click', () => go(-1));
    $('.lb__next', lbEl).addEventListener('click', () => go(1));
    lbEl.addEventListener('click', e => { if (e.target === lbEl || e.target.classList.contains('lb__fig')) close(); });
    addEventListener('keydown', e => { if (!lbEl.classList.contains('is-open')) return; if (e.key === 'Escape') close(); if (e.key === 'ArrowLeft') go(-1); if (e.key === 'ArrowRight') go(1); });
  }
  $$('[data-top]').forEach(b => b.addEventListener('click', () => (lenis ? lenis.scrollTo(0, { duration: 2.2 }) : scrollTo({ top: 0, behavior: 'smooth' }))));

  if (reduce || !hasLib) { root.classList.add('no-motion', 'ready'); return; }

  const { gsap, ScrollTrigger } = window;
  gsap.registerPlugin(ScrollTrigger);
  root.classList.add('ready');
  const lerp = (a, b, t) => a + (b - a) * t;

  /* ---------- Lenis ---------- */
  lenis = new Lenis({ duration: 1.3, easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)), smoothWheel: true, wheelMultiplier: 0.9 });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add(t => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);
  gsap.ticker.add(() => { if (window.AJGL) AJGL.scroll = lenis.velocity || 0; });

  $$('a[href*="#"]').forEach(a => a.addEventListener('click', e => {
    const u = new URL(a.href, location.href);
    const norm = p => p.replace(/index\.php$/, '');
    if (norm(u.pathname) !== norm(location.pathname) || !u.hash || u.hash === '#') return;
    const t = $(u.hash); if (!t) return;
    e.preventDefault();
    lenis.scrollTo(t, { offset: -10, duration: 2 });
    history.replaceState(null, '', u.hash);
  }));

  /* ---------- Custom cursor ---------- */
  if (matchMedia('(hover:hover) and (pointer:fine)').matches && $('.cursor')) {
    root.classList.add('has-cursor');
    const ring = $('.cursor'), dot = $('.cursor__dot'), label = $('.cursor__label');
    gsap.set([ring, dot], { xPercent: -50, yPercent: -50 });
    const rx = gsap.quickTo(ring, 'x', { duration: 0.55, ease: 'power3' }), ry = gsap.quickTo(ring, 'y', { duration: 0.55, ease: 'power3' });
    const dx = gsap.quickTo(dot, 'x', { duration: 0.1 }), dy = gsap.quickTo(dot, 'y', { duration: 0.1 });
    const glow = $('.cursor__glow');
    const gx = gsap.quickTo(glow, 'x', { duration: 1.1, ease: 'power3' }), gy = gsap.quickTo(glow, 'y', { duration: 1.1, ease: 'power3' });
    addEventListener('pointermove', e => { rx(e.clientX); ry(e.clientY); dx(e.clientX); dy(e.clientY); gx(e.clientX); gy(e.clientY); root.classList.add('cursor-on'); }, { passive: true });
    d.addEventListener('pointerleave', () => root.classList.remove('cursor-on'));
    d.addEventListener('pointerover', e => {
      const t = e.target.closest('a,button,[data-cursor],input,textarea,select');
      let st = '';
      if (t) st = t.matches('input,textarea,select') ? 'text' : (t.dataset.cursor || 'link');
      ring.dataset.state = st; dot.dataset.state = st;
      if (st === 'view') label.textContent = t.dataset.label || 'View';
    });
    addEventListener('pointerdown', () => ring.classList.add('is-down'));
    addEventListener('pointerup', () => ring.classList.remove('is-down'));
  }

  /* ---------- Page transitions ---------- */
  const pt = $('.pt');
  if (pt) {
    d.addEventListener('click', e => {
      const a = e.target.closest('a[href]');
      if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target === '_blank' || a.hasAttribute('download')) return;
      const u = new URL(a.href, location.href);
      if (u.origin !== location.origin || /^(tel|mailto)/.test(a.getAttribute('href'))) return;
      if (u.pathname === location.pathname) return;
      e.preventDefault(); lenis.stop();
      try { sessionStorage.setItem('aj61pt', '1'); } catch (x) {}
      gsap.fromTo(pt, { y: '112vh' }, { y: 0, duration: 0.85, ease: 'expo.inOut', onComplete: () => { location.href = a.href; } });
    });
    addEventListener('pageshow', ev => { if (ev.persisted) { gsap.set(pt, { y: '112vh' }); lenis.start(); } });
  }

  /* ---------- Hero images (WebGL with img fallback) ---------- */
  const glBox = $('.hero__media') || $('.phero__bg');
  const gl = glBox && window.AJGL ? AJGL.create(glBox) : null;

  /* ---------- Intro timeline ---------- */
  const heroLines = $$('.hero h1 .line > span, .phero h1 .line > span');
  heroLines.forEach(s => (s.style.transform = 'none'));
  const intro = gsap.timeline({ paused: true });
  const isHome = !!$('.hero');
  if (gl) intro.fromTo(gl.state, { zoom: isHome ? 1.4 : 1.3 }, { zoom: 1.02, duration: 2.8, ease: 'power3.out' }, 0);
  else intro.fromTo(isHome ? '.hero__media img' : '.phero__bg img', { scale: 1.3 }, { scale: 1.02, duration: 2.6, ease: 'power3.out' }, 0);
  intro.fromTo(heroLines, { yPercent: 115 }, { yPercent: 0, duration: 1.4, stagger: 0.12, ease: 'expo.out' }, 0.15);
  if (isHome) intro.fromTo('.hero__oct path', { strokeDasharray: 3000, strokeDashoffset: 3000 }, { strokeDashoffset: 0, duration: 3, ease: 'power2.inOut' }, 0.2);
  intro.fromTo('[data-intro]', { y: 34, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 1.2, stagger: 0.1, ease: 'expo.out' }, 0.6)
       .fromTo(header, { yPercent: -140 }, { yPercent: 0, duration: 1.2, ease: 'expo.out', clearProps: 'transform' }, 0.7);

  const curtain = $('.curtain');
  const first = !root.classList.contains('seen');
  if (curtain && first) {
    lenis.stop();
    const num = $('[data-count]', curtain), bar = $('.curtain__bar i', curtain), mark = $('.curtain__mark', curtain);
    const o = { n: 0 };
    gsap.timeline()
      .to(mark, { opacity: 1, scale: 1, duration: 0.9, ease: 'expo.out' }, 0)
      .to(o, { n: 100, duration: 2, ease: 'power2.inOut', onUpdate: () => { num.textContent = Math.round(o.n); } }, 0)
      .to(bar, { scaleX: 1, duration: 2, ease: 'power2.inOut' }, 0)
      .to('.curtain__count,.curtain__bar', { opacity: 0, duration: 0.4 }, 2.15)
      .to(mark, { scale: 1.25, opacity: 0, duration: 0.5, ease: 'power2.in' }, 2.15)
      .to(curtain, { y: '-112vh', duration: 1.1, ease: 'expo.inOut' }, 2.4)
      .add(() => { intro.play(); lenis.start(); root.classList.add('seen'); try { sessionStorage.setItem('aj61', '1'); } catch (e) {} }, 2.75)
      .set(curtain, { display: 'none' });
  } else if (root.classList.contains('pt-in') && pt) {
    lenis.stop();
    gsap.set(pt, { y: 0 });
    gsap.to(pt, { y: '-112vh', duration: 1.1, ease: 'expo.inOut', delay: 0.15, onComplete: () => { gsap.set(pt, { y: '112vh' }); root.classList.remove('pt-in'); lenis.start(); } });
    gsap.delayedCall(0.6, () => intro.play());
  } else { curtain && (curtain.style.display = 'none'); intro.play(); }

  /* ---------- Parallax on hero ---------- */
  if (isHome) {
    gsap.to('.hero__media', { yPercent: 14, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
    gsap.to('.hero__inner', { yPercent: -14, autoAlpha: 0.05, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: '80% top', scrub: true } });
    gsap.to('.hero__oct', { yPercent: -14, rotate: 8, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
    gsap.to('.badge', { yPercent: -60, ease: 'none', scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: true } });
  } else if ($('.phero')) {
    gsap.to('.phero__bg', { yPercent: 12, ease: 'none', scrollTrigger: { trigger: '.phero', start: 'top top', end: 'bottom top', scrub: true } });
  }

  /* ---------- Scroll cable ---------- */
  if ($('.cable')) {
    gsap.to('.cable i', { scaleY: 1, ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.4 } });
    gsap.to('.cable b', { top: '100%', ease: 'none', scrollTrigger: { start: 0, end: 'max', scrub: 0.4 } });
  }

  /* ---------- Velocity marquee ---------- */
  const mt = $('.marquee__track');
  if (mt) {
    const tl = gsap.to(mt, { xPercent: -50, duration: 55, ease: 'none', repeat: -1 });
    let dir = 1;
    gsap.ticker.add(() => {
      const v = lenis.velocity || 0; if (Math.abs(v) > 0.05) dir = Math.sign(v);
      tl.timeScale(lerp(tl.timeScale(), dir * (1 + Math.min(Math.abs(v) * 0.5, 9)), 0.08));
    });
  }
  // rotating badge
  const bdg = $('.badge svg');
  if (bdg) gsap.to(bdg, { rotate: 360, duration: 26, ease: 'none', repeat: -1 });

  /* ---------- Headings: word-mask reveal ---------- */
  $$('[data-split]').forEach(el => {
    const txt = el.textContent.trim().replace(/\s+/g, ' ');
    el.setAttribute('aria-label', txt);
    el.innerHTML = txt.split(' ').map(w => `<span class="sw" aria-hidden="true"><span>${w}</span></span>`).join(' ');
    const inner = $$('.sw > span', el);
    gsap.set(inner, { yPercent: 118 });
    ScrollTrigger.create({ trigger: el, start: 'top 88%', once: true, onEnter: () => gsap.to(inner, { yPercent: 0, duration: 1.25, stagger: 0.055, ease: 'expo.out' }) });
  });

  /* ---------- Statement scrub ---------- */
  const st = $('[data-scrub-text]');
  if (st) {
    st.innerHTML = st.textContent.trim().split(/\s+/).map(w => `<span class="w">${w}</span>`).join(' ');
    gsap.fromTo($$('.w', st), { opacity: 0.12 }, { opacity: 1, ease: 'none', stagger: 0.12, scrollTrigger: { trigger: st, start: 'top 82%', end: 'bottom 48%', scrub: 0.6 } });
  }

  /* ---------- Portal: PERFECT regular octagon grows from small to full viewport ---------- */
  const portal = $('[data-portal]');
  if (portal) {
    const mask = $('.portal__mask', portal);
    const portalImg = $('.portal__mask img', portal);
    const mob = matchMedia('(max-width:700px)').matches;
    const startSize = mob ? '34vmin' : '28vmin';

    /*
      IMPORTANT: width and height always stay identical.
      var(--hexP) is the mathematically regular 8-sided octagon.
      We do NOT morph the polygon into a rectangle; instead the same
      perfect octagon grows past the viewport until the whole screen is covered.
    */
    gsap.set(mask, {
      width: startSize,
      height: startSize,
      left: '50%',
      top: '50%',
      xPercent: -50,
      yPercent: -50,
      clipPath: 'polygon(29.289% 0%,70.711% 0%,100% 29.289%,100% 70.711%,70.711% 100%,29.289% 100%,0% 70.711%,0% 29.289%)'
    });

    const tl = gsap.timeline({
      defaults: { ease: 'none' },
      scrollTrigger: {
        trigger: portal,
        start: 'top top',
        end: '+=190%',
        pin: true,
        scrub: 0.7,
        anticipatePin: 1
      }
    });

    tl.to(mask, {
        width: '170vmax',
        height: '170vmax',
        duration: 1.15,
        ease: 'power2.inOut'
      }, 0)
      .fromTo(portalImg,
        { scale: 1.12 },
        { scale: 1, duration: 1.15, ease: 'power2.inOut' },
        0
      )
      .fromTo('.portal__word',
        { scale: 0.92, opacity: 1 },
        { scale: 1.12, opacity: 0, duration: 1 },
        0.1
      )
      .fromTo('.portal__copy > *',
        { y: 50, autoAlpha: 0 },
        { y: 0, autoAlpha: 1, stagger: 0.12, duration: 0.5, ease: 'power2.out' },
        0.82
      )
      .to({}, { duration: 0.45 });
  }

  /* ---------- Services: horizontal pinned gallery ---------- */
  const sc = $('[data-showcase]');
  const track = sc && $('[data-showcase-track]', sc);
  const mm = gsap.matchMedia();
  if (track) mm.add('(min-width:900px)', () => {
    const dist = () => Math.max(0, track.scrollWidth - innerWidth + parseFloat(getComputedStyle(track).paddingRight || 0));
    const h = gsap.to(track, { x: () => -dist(), ease: 'none', scrollTrigger: { trigger: sc, start: 'top top', end: () => '+=' + dist(), pin: true, scrub: 0.8, invalidateOnRefresh: true, anticipatePin: 1 } });
    gsap.to('.showcase__bar i', { scaleX: 1, ease: 'none', scrollTrigger: { trigger: sc, start: 'top top', end: () => '+=' + dist(), scrub: 0.8, invalidateOnRefresh: true } });
    $$('.card__img img', sc).forEach(img => gsap.fromTo(img, { xPercent: -9 }, { xPercent: 9, ease: 'none', scrollTrigger: { trigger: img.closest('.card'), containerAnimation: h, start: 'left right', end: 'right left', scrub: true } }));
  });

  /* ---------- Mobile service list ---------- */
  mm.add('(max-width:899px)', () => {
    ScrollTrigger.batch('.svc', { start: 'top 94%', once: true, onEnter: els => gsap.fromTo(els, { y: 40, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 1, stagger: 0.07, ease: 'expo.out' }) });
    gsap.set('.svc', { autoAlpha: 0 });
  });

  /* ---------- Pinned story ---------- */
  const story = $('[data-story]');
  if (story) {
    const layers = $$('.story__layer', story).slice(1), steps = $$('.story__step', story), bars = $$('.story__rail b', story), imgs = $$('.story__layer img', story);
    const tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: { trigger: story, start: 'top top', end: '+=260%', pin: true, scrub: 0.8, anticipatePin: 1 } });
    gsap.set(steps.slice(1), { autoAlpha: 0, y: 30 }); gsap.set(imgs, { scale: 1.15 });
    tl.to(imgs, { scale: 1, duration: 3 }, 0);
    bars[0] && tl.to(bars[0], { scaleY: 1, duration: 1 }, 0);
    steps.slice(1).forEach((s, i) => {
      const at = i + 1;
      tl.to(steps[i], { autoAlpha: 0, y: -30, duration: 0.35, ease: 'power2.in' }, at - 0.1)
        .to(layers[i], { clipPath: 'inset(0% 0 0 0)', duration: 0.7, ease: 'power2.inOut' }, at - 0.2)
        .to(s, { autoAlpha: 1, y: 0, duration: 0.5, ease: 'power2.out' }, at + 0.25);
      bars[at] && tl.to(bars[at], { scaleY: 1, duration: 1 }, at);
    });
    tl.to({}, { duration: 0.5 });
  }

  /* ---------- Process line ---------- */
  const pl = $('.process__line i');
  if (pl) {
    const horiz = matchMedia('(min-width:900px)').matches;
    gsap.fromTo(pl, horiz ? { scaleX: 0 } : { scaleY: 0 }, { [horiz ? 'scaleX' : 'scaleY']: 1, ease: 'none', scrollTrigger: { trigger: '.process__grid', start: 'top 75%', end: 'bottom 70%', scrub: 0.6 } });
  }

  /* ---------- Parallax images, reveals, footer ---------- */
  $$('[data-parallax]').forEach(el => gsap.fromTo(el, { yPercent: -7 }, { yPercent: 7, ease: 'none', scrollTrigger: { trigger: el.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } }));
  ScrollTrigger.batch('.rv', { start: 'top 90%', once: true, onEnter: els => gsap.to(els, { opacity: 1, y: 0, duration: 1.2, stagger: 0.09, ease: 'expo.out', clearProps: 'transform' }) });
  /* ---------- Gallery honeycomb ---------- */
  const gal = $('[data-gallery]');
  if (gal) {
    const hexes = $$('.hx', gal);
    gsap.set(hexes, { scale: 0.4, rotate: -16, autoAlpha: 0 });
    $$('.hexrow', gal).forEach(row => ScrollTrigger.create({ trigger: row, start: 'top 90%', once: true, onEnter: () => gsap.to($$('.hx', row), { scale: 1, rotate: 0, autoAlpha: 1, duration: 1.4, ease: 'expo.out', stagger: { each: 0.09, from: 'center' }, clearProps: 'transform,opacity,visibility' }) }));
    $$('.hexrow', gal).forEach((row, i) => gsap.fromTo(row, { x: (i % 2 ? 1 : -1) * (innerWidth < 700 ? 10 : 46) }, { x: (i % 2 ? -1 : 1) * (innerWidth < 700 ? 10 : 46), ease: 'none', scrollTrigger: { trigger: gal, start: 'top bottom', end: 'bottom top', scrub: true } }));
    $$('.hx[data-src] img', gal).forEach((img, i) => gsap.fromTo(img, { yPercent: -5 - (i % 3) * 2 }, { yPercent: 5 + (i % 3) * 2, ease: 'none', scrollTrigger: { trigger: img.closest('.hx'), start: 'top bottom', end: 'bottom top', scrub: true } }));
  }

  /* ---------- Footer ---------- */
  const fl = $$('.footer__big .fl > span');
  if (fl.length) {
    gsap.set(fl, { yPercent: 115 });
    ScrollTrigger.create({ trigger: '.footer__cta', start: 'top 80%', once: true, onEnter: () => gsap.to(fl, { yPercent: 0, duration: 1.5, stagger: 0.14, ease: 'expo.out' }) });
  }
  const fw = $('.footer-word');
  if (fw) {
    gsap.fromTo(fw, { yPercent: 30, opacity: 0.25 }, { yPercent: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: '.footer__grid', start: 'top 85%', end: 'bottom 40%', scrub: true } });
    gsap.fromTo(fw, { '--p': '0%' }, { '--p': '100%', ease: 'none', scrollTrigger: { trigger: '.footer__bottom', start: 'top 100%', end: 'bottom bottom', scrub: true } });
  }

  /* ---------- Magnetic ---------- */
  if (matchMedia('(hover:hover) and (pointer:fine)').matches) {
    $$('[data-magnetic]').forEach(b => {
      const x = gsap.quickTo(b, 'x', { duration: 0.6, ease: 'power3' }), y = gsap.quickTo(b, 'y', { duration: 0.6, ease: 'power3' });
      b.addEventListener('pointermove', e => { const r = b.getBoundingClientRect(); x((e.clientX - r.left - r.width / 2) * 0.25); y((e.clientY - r.top - r.height / 2) * 0.35); });
      b.addEventListener('pointerleave', () => { x(0); y(0); });
    });
  }

  (d.fonts && d.fonts.ready ? d.fonts.ready : Promise.resolve()).then(() => ScrollTrigger.refresh());
  addEventListener('load', () => ScrollTrigger.refresh());
})();
