/* AJ61 — WebGL image layer: liquid ripple that follows the pointer + RGB split on scroll speed.
   Falls back silently to the normal <img> if WebGL is unavailable. */
window.AJGL = (function () {
  const lowPower = matchMedia('(prefers-reduced-motion: reduce)').matches || matchMedia('(max-width: 767px)').matches || matchMedia('(pointer: coarse)').matches || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (navigator.deviceMemory && navigator.deviceMemory <= 4);
  const VS = 'attribute vec2 p;varying vec2 v;void main(){v=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
  const FS = `precision mediump float;varying vec2 v;uniform sampler2D t;
  uniform vec2 res,img,mouse;uniform float time,zoom,off,vel,scr,hover;
  vec2 cover(vec2 uv){float ra=res.x/res.y,ia=img.x/img.y;vec2 s=ra>ia?vec2(1.,ia/ra):vec2(ra/ia,1.);return (uv-.5)*s+.5;}
  void main(){
    vec2 uv=(v-.5)/zoom+.5; uv.y+=off;
    vec2 d=v-mouse; d.x*=res.x/res.y; float dist=length(d);
    float w=exp(-dist*4.2)*hover;
    vec2 dir=d/(dist+1e-3);
    uv+=dir*sin(dist*34.-time*2.4)*(.006+vel*.05)*w;
    uv+=dir*w*.012;
    uv+=.0018*vec2(sin(v.y*8.+time*.6),cos(v.x*8.+time*.5));
    uv=cover(uv);
    float s=scr*.0016;
    vec3 c=vec3(texture2D(t,uv+vec2(0.,s)).r,texture2D(t,uv).g,texture2D(t,uv-vec2(0.,s)).b);
    gl_FragColor=vec4(c,1.);
  }`;
  const api = { scroll: 0 };
  api.create = function (box) {
    if (lowPower) return null;
    try {
      const img = box.querySelector('img');
      if (!img) return null;
      const cv = document.createElement('canvas');
      cv.className = 'gl-canvas';
      const gl = cv.getContext('webgl', { antialias: false, alpha: false, powerPreference: 'high-performance' });
      if (!gl) return null;
      const mk = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
      const pr = gl.createProgram(); gl.attachShader(pr, mk(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, mk(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr);
      if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return null;
      gl.useProgram(pr);
      const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
      const U = n => gl.getUniformLocation(pr, n);
      const u = { res: U('res'), img: U('img'), mouse: U('mouse'), time: U('time'), zoom: U('zoom'), off: U('off'), vel: U('vel'), scr: U('scr'), hover: U('hover') };
      const tex = gl.createTexture();
      const state = { zoom: 1.02, off: 0 };
      let ready = false, imgW = 1, imgH = 1;
      const upload = () => {
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        imgW = img.naturalWidth; imgH = img.naturalHeight; ready = true;
        box.appendChild(cv); box.classList.add('gl-on');
      };
      if (img.complete && img.naturalWidth) upload(); else img.addEventListener('load', upload, { once: true });
      const size = () => {
        const dpr = Math.min(window.devicePixelRatio || 1, 1.6), r = box.getBoundingClientRect();
        cv.width = Math.max(2, Math.round(r.width * dpr)); cv.height = Math.max(2, Math.round(r.height * dpr));
        gl.viewport(0, 0, cv.width, cv.height);
      };
      size(); new ResizeObserver(size).observe(box);
      let mx = .5, my = .5, tx = .5, ty = .5, hov = 0, hovT = 0, vel = 0, scr = 0, t0 = performance.now(), visible = true, raf = 0;
      const onMove = e => {
        const r = box.getBoundingClientRect();
        const inside = e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top && e.clientY <= r.bottom;
        tx = (e.clientX - r.left) / r.width; ty = 1 - (e.clientY - r.top) / r.height; hovT = inside ? 1 : 0;
      };
      window.addEventListener('pointermove', onMove, { passive: true });
      new IntersectionObserver(es => { visible = es[0].isIntersecting; if (visible && !raf) loop(); }, { threshold: 0 }).observe(box);
      const loop = () => {
        if (!visible) { raf = 0; return; }
        if (ready) {
          const px = mx, py = my;
          mx += (tx - mx) * .08; my += (ty - my) * .08; hov += (hovT - hov) * .06;
          vel += (Math.min(Math.hypot(mx - px, my - py) * 22, 1) - vel) * .1;
          scr += (api.scroll - scr) * .12;
          gl.uniform2f(u.res, cv.width, cv.height); gl.uniform2f(u.img, imgW, imgH);
          gl.uniform2f(u.mouse, mx, my); gl.uniform1f(u.time, (performance.now() - t0) / 1000);
          gl.uniform1f(u.zoom, state.zoom); gl.uniform1f(u.off, state.off);
          gl.uniform1f(u.vel, vel); gl.uniform1f(u.scr, scr); gl.uniform1f(u.hover, hov);
          gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        }
        raf = requestAnimationFrame(loop);
      };
      loop();
      return { state };
    } catch (e) { return null; }
  };
  return api;
})();
