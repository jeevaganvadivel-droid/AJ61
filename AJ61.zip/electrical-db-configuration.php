<?php
$serviceKey='electrical-db-configuration';
require __DIR__.'/service-page.php';
