<?php
require __DIR__.'/includes/bootstrap.php';
$pageTitle='Contact AJ SIXTY ONE PTE LTD | Singapore';
$pageDescription='Contact AJ SIXTY ONE for electrical, plumbing, structural and project service enquiries in Singapore.';
$pageKeywords='AJ SIXTY ONE contact Singapore, electrical contractor Singapore';
$canonical=canonical('contact.php');
$preloadImage='assets/img/web/hero-streetlight.webp';
require __DIR__.'/includes/header.php';
?>
<section class="phero">
  <div class="phero__bg"><img src="<?=e(asset('assets/img/web/AJ Sixty One_ Contact Us.webp'))?>" alt=""></div>
  <div class="container phero__inner">
    <div>
      <h1 aria-label="Bring us the next challenge."><span class="line"><span>Bring us the</span></span><span class="line"><span>next challenge.</span></span></h1>
      <p data-intro>Send your scope, location, photos or drawings. For the fastest response, WhatsApp the project details directly.</p>
    </div>
    <div class="glass contact-direct" data-intro><a href="<?=e(whatsapp_url('Hi AJ SIXTY ONE, I would like to discuss a project.'))?>" target="_blank" rel="noopener"><small>WhatsApp</small><b><?=e(WHATSAPP_NUMBER)?></b></a><a href="tel:<?=CONTACT_PHONE_RAW?>"><small>Call</small><b><?=e(CONTACT_PHONE)?></b></a><a href="mailto:<?=e(CONTACT_EMAIL)?>"><small>Email</small><b><?=e(CONTACT_EMAIL)?></b></a><div><small>Address</small><b><?=e(COMPANY_ADDRESS)?></b></div></div>
  </div>
</section>
<section class="lead" id="quote"><div class="container lead__grid"><div class="lead__copy"><h2 data-split>Tell us what needs doing.</h2><p class="rv">Use the form, or message us on WhatsApp for a quicker conversation.</p></div><div class="lead__form rv"><?php require __DIR__.'/includes/lead-form.php';?></div></div></section>
<?php require __DIR__.'/includes/footer.php';?>
