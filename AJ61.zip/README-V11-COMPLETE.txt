AJ SIXTY ONE — V11 COMPLETE WEBSITE
======================================

WHAT IS INCLUDED
- Premium V10 octagonal design retained
- Homepage conversion sections: Industries, Example Project Scopes, Why AJ61, FAQ
- 11 SEO-focused service pages
- Visible FAQ content on every service page
- Service, FAQ, Breadcrumb, Organization, LocalBusiness, WebSite and WebPage structured data
- Canonical, Open Graph, Twitter card, hreflang and social-share image
- Privacy Policy and consent link
- 404 page
- XML sitemap, robots.txt, llms.txt, manifest and favicon set
- Hardened enquiry form: CSRF, honeypot, basic rate limit, input length checks and header-injection checks
- AVIF/WebP responsive hero/service images
- Hero/LCP image preload
- Width/height helpers for reduced layout shift
- Long-lived cache headers, compression and security headers
- Low-power/mobile WebGL fallback
- Existing GSAP / ScrollTrigger / Lenis design preserved

IMPORTANT: SEO cannot guarantee Google position #1 or a literal Lighthouse 100 on every device/network. This package is built toward strong technical SEO, Core Web Vitals and responsive best practices. Real rankings depend on content quality, competition, links, Google Business Profile, real projects, reviews and ongoing updates.

LOCAL XAMPP
Copy the contents into C:\\xampp\\htdocs\\AJ61\\ and open http://localhost/AJ61/
Press Ctrl+F5 after replacing an older version.

WHEN YOU REPLACE IMAGES LATER
The main temporary source images are in assets/img/web/.
For best performance, regenerate the matching files in assets/img/web/responsive/ at 960px and 1600px in both WebP and AVIF. Until then the original WebP fallback still works, but the old responsive variants should also be replaced so visitors do not see the previous image.
Gallery images are in assets/img/gallery/.

WHEN YOU ADD REAL PROJECTS
Replace the three "Example scope" cards on index.php with truthful project name, location, scope, services and outcome. Do not publish invented client names, project values, testimonials, licences or certifications.

EMAIL FORM
contact_submit.php currently uses PHP mail(). Many hosting providers disable or restrict mail(). For production reliability, configure your hosting SMTP / PHPMailer if mail() does not deliver. The website form itself is validated and protected, but SMTP credentials are intentionally not included in this package.

SEO LAUNCH CHECKLIST
1. Upload to https://ajsixtyone.sg/ and verify HTTPS.
2. Submit https://ajsixtyone.sg/sitemap.xml to Google Search Console and Bing Webmaster Tools.
3. Create/complete Google Business Profile with matching company name, address, phone and website.
4. Replace temporary images with real AJ61 project photography.
5. Add real project case studies and genuine client testimonials when available.
6. Run PageSpeed Insights on the live domain after CDN/server caching is active.
7. Check form email delivery from the live server.
8. Test 360, 390, 430, 768, 1024, 1366, 1440 and 1920 widths.
