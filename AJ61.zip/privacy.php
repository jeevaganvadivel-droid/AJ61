<?php
require __DIR__.'/includes/bootstrap.php';
$pageTitle='Privacy Policy | '.SITE_NAME; $pageDescription='Privacy information for enquiries submitted through the AJ SIXTY ONE website.'; $canonical=canonical('privacy.php');
require __DIR__.'/includes/header.php';
?>
<section class="legal-hero"><div class="container"><span class="eyebrow">PRIVACY</span><h1>Privacy Policy</h1><p>How information submitted through this website is handled.</p></div></section>
<section class="legal"><div class="container legal__body">
<h2>Information you provide</h2><p>When you use our enquiry form, you may provide your name, company, phone number, email address, selected service and project details. You may also choose to contact us directly by phone, email or WhatsApp.</p>
<h2>How we use the information</h2><p>We use enquiry information to review your request, contact you about the project, prepare follow-up information or quotations, and maintain reasonable business records relating to the enquiry.</p>
<h2>Sharing and service providers</h2><p>Information may be handled by service providers that support website hosting, email or business communications where required to operate those services. We do not state that information is sold to advertisers.</p>
<h2>Retention</h2><p>Enquiry information may be retained for as long as reasonably necessary for business, operational, contractual or legal purposes.</p>
<h2>Your request</h2><p>If you want to ask about personal information submitted through this website, contact <a href="mailto:<?=e(CONTACT_EMAIL)?>"><?=e(CONTACT_EMAIL)?></a>.</p>
<h2>Third-party communication links</h2><p>Links to services such as WhatsApp open third-party platforms. Their privacy practices are governed by their own terms and policies.</p>
<h2>Updates</h2><p>This policy may be updated when website functions or business processes change. Last updated: 9 October 2026.</p>
</div></section>
<?php require __DIR__.'/includes/footer.php'; ?>
