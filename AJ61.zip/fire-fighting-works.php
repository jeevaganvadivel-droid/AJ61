<?php
$serviceKey='fire-fighting-works';
require __DIR__.'/service-page.php';
