<?php
$serviceKey='trunking-fittings';
require __DIR__.'/service-page.php';
