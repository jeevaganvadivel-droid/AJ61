AJ SIXTY ONE - V8 "LIVE WIRE" (premium edition)
=================================

RUN LOCALLY (XAMPP):  copy folder to C:\xampp\htdocs\AJ61\  ->  http://localhost/AJ61/
RUN LIVE:             upload everything to your domain root. Links auto-detect.

WHAT'S NEW IN V9
- New header: full-width bar, real purple logo (original colours), rolling-text links, WhatsApp icon, hexagon buttons
- New full-screen menu with honeycomb pattern, all services and contact
- Hexagon cursor with purple spotlight; hexagon service frames; hexagon portal
- Honeycomb photo gallery with scroll animation + hexagon lightbox (click a tile)
- New footer: big call-to-action, services list, WhatsApp, animated wordmark
- WhatsApp is now the real WhatsApp icon everywhere (header, hero, floating button, footer)

GALLERY PHOTOS: replace the 12 files in assets/img/gallery/ (g01.webp to g12.webp). Portrait ~760x880 works best.
LOGO: the header/footer use assets/img/aj61-logo-tile.png (your original logo, cropped). Replace that file to update it everywhere.

V8 FEATURES
- WebGL liquid hero: the photo ripples under the mouse and splits colour with scroll speed (falls back to normal image)
- Custom cursor (ring that grows, 'View' on service cards), film grain, rotating badge
- Counter preloader (first visit) + curved page-to-page transitions
- Octagon 'portal' section: a window expands to fill the screen on scroll
- Services as a horizontal pinned gallery (list on mobile)
- Headlines reveal word by word; marquee speeds up with scroll

EARLIER (V7)
- Real smooth scrolling: Lenis (inertia scroll) + GSAP ScrollTrigger, bundled in assets/js/vendor (no CDN needed)
- Cinematic hero: image zoom-settle, masked headline reveal, drawing octagon (from your logo), parallax
- Glass floating header that hides on scroll-down, shows on scroll-up. Full-screen animated mobile menu
- Scroll cable on the left edge (desktop) that fills as you scroll
- Words in the statement light up as you scroll
- Services list with a cursor-following image preview (thumbnails on mobile)
- Pinned story section: images wipe from one to the next while copy changes
- Process line that fills on scroll, magnetic buttons, first-visit logo curtain
- Fonts bundled locally (Bricolage Grotesque + Figtree) - works offline
- Reduced-motion users get a calm, static version automatically

HOW TO USE YOUR OWN IMAGES
Replace these files, keeping the SAME NAME (any size works; they are cropped to fit; use landscape 2000px+ wide, under ~400 KB, WebP or JPG):
  assets/img/web/hero-construction.webp  -> homepage hero
  assets/img/web/hero-electrical.webp    -> story step 1, electrical service pages
  assets/img/web/hero-structure.webp     -> story step 2, cable tray / structural pages
  assets/img/web/hero-painting.webp      -> story step 3, painting pages
  assets/img/web/hero-plumbing.webp      -> plumbing pages
  assets/img/web/hero-streetlight.webp   -> street light pages + Contact hero
To give each service its own photo, add the file and change the 'image' path for that service in includes/service-data.php.

CHANGE TEXT / CONTACT DETAILS
  includes/bootstrap.php  -> phone, email, WhatsApp, address
  includes/service-data.php -> service names and descriptions
  index.php -> homepage copy

COLORS: edit the variables at the top of assets/css/style.css (--brand is your logo purple).
FORM: uses PHP mail(). If your host blocks it, switch contact_submit.php to SMTP/PHPMailer.
