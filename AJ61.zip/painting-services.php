<?php
$serviceKey='painting-services';
require __DIR__.'/service-page.php';
