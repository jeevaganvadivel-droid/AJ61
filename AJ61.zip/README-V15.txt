AJ61 V15 — True Octagon Showcase

Changes:
- Horizontal scrolling service cards are now full 8-sided octagons.
- Inner image frame uses the same 8-sided geometry.
- Service labels use an octagonal/hexagonal capsule treatment.
- Arrow buttons use the AJ61 8-sided shape.
- CTA card follows the same geometry.
- Mobile service thumbnails/actions use octagonal shapes.
